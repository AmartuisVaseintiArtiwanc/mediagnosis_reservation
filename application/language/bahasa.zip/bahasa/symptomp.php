<?php 
	$lang["CreateSymptompSucess001"]="Master Gejala berhasil ditambahkan";
	$lang["CreateSymptompErrorDatabase002"]="Terjadi kesalahan saat menambahkan data. Harap coba lagi";
	$lang["CreateSymptompErrorDuplicate003"]="sudah ada";
?>